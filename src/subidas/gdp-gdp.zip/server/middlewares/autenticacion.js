const jwt = require('jsonwebtoken');

// varificar token
let verificaToken = (req, res, next) => {
    let token = req.params.token;
    jwt.verify( token, "seed-encuentro-del-suroeste", (err, decoded) =>{

        if (err) {
            return res.json({
                ok: false,
                err
            });
        }
        
        req.usuario = decoded;
        next();
    });
};


let verificaAdmin_Role = (req, res, next) => {

    let usuario = req.usuario;

    if (usuario.role === 'ADMIN') {
        next();
    } else {
        return res.json({
            ok: false,
            err: {
                message: 'El usuario no es administrador'
            }
        });
    }
};

module.exports = {verificaToken, verificaAdmin_Role};