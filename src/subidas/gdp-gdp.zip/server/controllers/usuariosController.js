const Usuario=require("../models/tbl_usuarios");
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const GuardarUsuario=(req,res)=>{
    bcrypt.hash(req.body.contrasena, 10,(err,hash)=>{
        if(err){
            return res.json({
                ok:false,
                err
            });
        }
        req.body.contrasena=hash;
        var User=new Usuario(req.body);
        User.save({new:true},(error,user)=>{
            if(error){
                return res.json({
                    ok:false,
                    error
                });
            }
            res.json({
                ok:true,
                user
            });
        });
    });
    
}

const IniciarSesion=(req,res)=>{
    let {usuario,contrasena} = req.body;
    Usuario.find({
        $or:[
                {usuario: {$regex: usuario, $options: "i"}},
                {correo: {$regex: usuario, $options: "i"}}
            ]
    })
    .exec((err, loginDB) => {
        if (err) {
            return  res.json({
                ok: false,
                err
            });
        }        
        if (!loginDB[0]) {
            return res.json({
                ok: false,
                err: ""
            });
        }
        loginDB=loginDB[0];
        if (!bcrypt.compareSync(contrasena, loginDB.contrasena )) {
            return res.json({
                ok: false,
                err:""
            });
        }
        loginDB.contrasena=undefined;
        let token = jwt.sign({
            login: loginDB
        }, "seed-encuentro-del-suroeste", {expiresIn: '10h'}); 

        res.json({
            ok:true,
            token
        });
    });
}

module.exports={
    GuardarUsuario,
    IniciarSesion
}