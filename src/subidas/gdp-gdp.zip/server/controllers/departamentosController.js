const Dep=require('../models/tbl_departamentos');

const guardarLote=(req,res)=>{
    Dep.insertMany(req.body,(err,lista)=>{
        if(err){
            return res.json({
                ok:false,
                err
            });
        }
        res.json({
            ok:true,
            lista:req.body
        });
    });
}
const listar=(req,res)=>{
    Dep.find({})
    .exec((err,lista)=>{
        if(err){
            return res.json({
                ok:false,
                err
            });
        }
        res.json({
            ok:true,
            lista
        });
    });
}

module.exports={
    guardarLote,
    listar
}