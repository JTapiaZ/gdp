const Persona = require('../models/tbl_personas');
const Mail=require('./mailController');

const guardar=(req,res)=>{
    delete req.body["_id"];
    var u=new Persona(req.body);
    u.save({new:true},(error,PersonaDB)=>{
        if(error){
            return res.json(
                {
                    ok:false,
                    error
                }
            );
        }
        if(PersonaDB.correo!==""){
            Mail.SendMail(PersonaDB);
        }
        res.json({
            ok:true,
            PersonaDB
        });
    });
}

const guardarLote=(req,res)=>{
    Persona.insertMany(req.body,(error,registros)=>{
        if(error){
            return res.json(
                {
                    ok:false,
                    error
                }
            );
        }
        res.json({
            ok:true,
            registros
        });
    });
}

const Buscar=(req,res)=>{
    const {id}=req.params;
    Persona.find({_id:id})
    .populate("ciudad")
    .exec((err,Persona)=>{
        if(err){
            return res.json({
                ok:false,
                Persona:{}
            });
        }
        res.json({
            ok:true,
            Persona
        });
    });
}

const listar=(req,res)=>{
    Persona.find({})
    .populate("ciudad")
    .exec((err, Persona)=>{
        if(err){
            return res.json({
                ok:false,
                lista:null
            });
        }
        res.json({
            ok:true,
            lista:Persona
        });
    });
}
const inhabilitar=(req,res)=>{
    let est=false;
    if(req.params.e){
        est=true;
    }
    Persona.findOneAndUpdate({_id:req.params.id},{estado:est},{new:true},(err,persona)=>{
        if(err){
            return res.json({
                ok:false,
                err
            });
        }
        res.json({
            ok:true,
            persona
        });
    });
}

const modificar=(req,res)=>{
    Persona.findOneAndUpdate({_id:req.params.id},req.body,{new:true},(error,PersonaDB)=>{
        if(error){
            return res.json({
                ok:false,
                error
            });
        }
        if(req.params.acepta && PersonaDB.correo!==""){
            Mail.SendMail(PersonaDB);
        }
        res.json({
            ok:true,
            PersonaDB
        });
    });
}

const permitido=(req,res)=>{
    const {id}=req.params;
    Persona.findOne({identificacion:id})
    .populate("ciudad")
    .exec((err,Persona)=>{
        if(err){
            return res.json({
                ok:false,
                Persona:{}
            });
        }
        if(!Persona){
            return res.json({
                ok:false,
                mensaje:"No existe este registro."
            });
        }
        let mensaje="La persona ha sido aceptada.";
        if(Persona.gen){
            mensaje="La persona ha sido rechazada.";
        }
        res.json({
            ok:true,
            Persona,
            mensaje
        });
    });
}

const aceptados=(req,res)=>{
    Persona.find({gen:false})
    .populate("ciudad")
    .exec((err,lista)=>{
        if(err){
            return res.json({
                ok:false,
                lista:{}
            });
        }
        res.json({
            ok:true,
            lista
        });
    });
}

module.exports= {
    listar,
    guardar,
    Buscar,
    inhabilitar,
    modificar,
    guardarLote,
    permitido,
    aceptados
}