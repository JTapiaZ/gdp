
const nodemailer = require('nodemailer');
const path=require("path");

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'encuentrosuroeste@gmail.com',
    pass: 'suroeste12345'
  }
});

const html=(p)=>{
    if(p.gen){
        return(`
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-Compatible" content="ie=edge">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
            <link href="https://fonts.googleapis.com/css?family=Heebo:400,500|Lato:400,700|Open+Sans|Roboto:400,500" rel="stylesheet">
            <title>Mensaje Correo</title>
        </head>
        <body style="
            width: 100%;
            background: rgb(235, 235, 235);
            height: 450px;
            box-sizing: border-box;
            border: 0;
            list-style: none;
            outline: 0;
            text-decoration: none;
            color: black;
        ">
            <div class="contenedor"
                style="
                    height: 400px;
                    width: 550px;
                    padding: 20px;
                    background: rgb(255, 255, 255);
                    border: 1px solid rgb(218, 218, 218);
                    text-align: center;
                    border-radius: 5px;
                    margin: 100px auto;
                    box-sizing: border-box;
                    list-style: none;
                    outline: 0;
                    text-decoration: none;
                "
            >
                <img style="
                    width: 200px;
                    height:100px;
                    padding: 0;
                    margin: 0 auto;
                    box-sizing: border-box;
                    border: 0;
                    list-style: none;
                    outline: 0;
                    text-decoration: none;
                " src="cid:unique@kreata.ee" title="Encuentro de dirigentes del suroeste antioqueño.">
                <br/>
                <h1 style="
                    font-family: 'Lato', sans-serif;
                    padding: 0;
                    margin: 0;
                    box-sizing: border-box;
                    border: 0;
                    list-style: none;
                    outline: 0;
                    text-decoration: none;
                ">${p.nombre1} ${p.nombre2} ${p.apellido1} ${p.apellido2}</h1>
                <br/>
                <hr style="
                    width: 70px;
                    height: 2px;
                    background: rgb(182, 0, 0);
                    padding: 0;
                    box-sizing: border-box;
                    border: 0;
                    list-style: none;
                    outline: 0;
                    text-decoration: none;
                "/>
                <br/>
                <h2 style="
                    font-family: 'Roboto', sans-serif;
                    font-weight: 500;
                    margin-bottom: 30px;
                    padding: 0;
                    box-sizing: border-box;
                    border: 0;
                    list-style: none;
                    outline: 0;
                    text-decoration: none;
                ">
                    Gracias por establecer contacto con nosotros.
                </h2>
                <br/>
                <h3 style="
                    font-family: 'Roboto', sans-serif;
                    font-weight: 400;
                    color: rgb(182, 0, 0);
                    padding: 0;
                    margin: 0;
                    box-sizing: border-box;
                    border: 0;
                    list-style: none;
                    outline: 0;
                    text-decoration: none;
                ">
                    Su solicitud está siendo procesada.<br/>
                    En los próximos días recibirá respuesta.
                </h3>  
            </div>
        </body>
        </html>
        `);
    }else{
        return(`
            <!DOCTYPE html>
            <html lang="es">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <meta http-equiv="X-UA-Compatible" content="ie=edge">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
                <link href="https://fonts.googleapis.com/css?family=Heebo:400,500|Lato:400,700|Open+Sans|Roboto:400,500" rel="stylesheet">
                <title>Mensaje Correo</title>
            </head>
            <body style="
                width: 100%;
                background: rgb(235, 235, 235);
                height: 650px;
                box-sizing: border-box;
                border: 0;
                list-style: none;
                outline: 0;
                text-decoration: none;
                color: black;
            ">
                <div class="contenedor"
                    style="
                        height: 600px;
                        width: 600px;
                        padding: 25px;
                        background: rgb(255, 255, 255);
                        border: 1px solid rgb(218, 218, 218);
                        text-align: center;
                        border-radius: 5px;
                        margin: 100px auto;
                        box-sizing: border-box;
                        list-style: none;
                        outline: 0;
                        text-decoration: none;
                    "
                >
                    <img style="
                        width: 200px;
                        height:100px;
                        padding: 0;
                        margin: 0 auto;
                        box-sizing: border-box;
                        border: 0;
                        list-style: none;
                        outline: 0;
                        text-decoration: none;
                    " src="cid:unique@kreata.ee" title="Encuentro de dirigentes del suroeste antioqueño."> 
                    <br/>
                    <h1 style="
                        font-family: 'Lato', sans-serif;
                        padding: 0;
                        margin: 0;
                        box-sizing: border-box;
                        border: 0;
                        list-style: none;
                        outline: 0;
                        text-decoration: none;
                    ">${p.nombre1} ${p.nombre2} ${p.apellido1} ${p.apellido2}</h1>
                    <br/>
                    <hr style="
                        width: 70px;
                        height: 2px;
                        background: rgb(182, 0, 0);
                        padding: 0;
                        box-sizing: border-box;
                        border: 0;
                        list-style: none;
                        outline: 0;
                        text-decoration: none;
                    "/>
                    <br/>
                    <h2 style="
                        font-family: 'Roboto', sans-serif;
                        font-weight: 500;
                        margin-bottom: 30px;
                        padding: 0;
                        box-sizing: border-box;
                        border: 0;
                        list-style: none;
                        outline: 0;
                        text-decoration: none;
                    ">
                    Reciba un cálido saludo de nuestra parte.
                    </h2>
                    <br/>
                    <h3 style="
                        font-family: 'Roboto', sans-serif;
                        font-weight: 400;
                        padding: 0;
                        margin-bottom: 30px;
                        box-sizing: border-box;
                        border: 0;
                        list-style: none;
                        outline: 0;
                        text-decoration: none;
                    ">
                        El presente mensaje tiene como finalidad confirmar su registro exitoso al <span style="color:rgb(182, 0, 0);">XXXI Encuentro de
                        Dirigentes del Suroeste Antioqueño</span>, que se llevará a cabo en el municipio de Andes el próximo 
                        viernes 14 de junio de 2019.
                    </h3> 
                    <h3 style="
                        font-family: 'Roboto', sans-serif;
                        font-weight: 400;
                        padding: 0;
                        margin: 0;
                        box-sizing: border-box;
                        border: 0;
                        list-style: none;
                        outline: 0;
                        text-decoration: none;
                    ">
                        Para nosotros como Corporación es grato poder contar con usted como invitado a este
                        importante Encuentro que reúne la dirigencia del Suroeste Antioqueño y el país.
                    </h3>   
                </div>
            </body>
            </html>
        `)
    }
}

const SendMail=(persona) => {    
    if( /(.+)@(.+){2,}\.(.+){2,}/.test(persona.correo)){
        
        const mailOptions={
            from: 'encuentrosuroeste@gmail.com',
            to:persona.correo,
            subject: 'Encuentro de dirigentes del suroeste antioqueño.',
            html:html(persona),
            attachments: [{
                filename: 'logo.jpg',
                path: path.resolve('./server/images/logo.jpg'),
                cid: 'unique@kreata.ee'
            }]
        }
        transporter.sendMail(mailOptions);
    }
}

module.exports = {
    SendMail
}