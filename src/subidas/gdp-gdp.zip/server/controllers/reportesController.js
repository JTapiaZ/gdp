// const PDFDocument = require('pdfkit');
const fs=require("fs");
const path=require("path");
var xl = require('excel4node');

const Crear=(req,res)=>{
 
    // Create a new instance of a Workbook class
    var wb = new xl.Workbook();
    
    // Add Worksheets to the workbook
    var ws = wb.addWorksheet('Información');
    // var ws2 = wb.addWorksheet('Sheet 2');
    
    // Create a reusable style
    var style = wb.createStyle({
        font: {
            color: '#FF0800',
            size: 12,
        },
        numberFormat: '$#,##0.00; ($#,##0.00); -',
    });
    
    /*/ Set value of cell A1 to 100 as a number type styled with paramaters of style
    ws.cell(1, 1)
    .number(100)
    .style(style);
    
    // Set value of cell B1 to 200 as a number type styled with paramaters of style
    ws.cell(1, 2)
    .number(200)
    .style(style);
    
    // Set value of cell C1 to a formula styled with paramaters of style
    ws.cell(1, 3)
    .formula('A1 + B1')
    .style(style);*/
    let cabecera=["N°","Identificación","Primer nombre","Segundo nombre","Primer apellido","Segundo apellido","Correo","Celular","Ciudad","Departamento","Empresa","Cargo","Sector"];
    for (let i = 0; i <cabecera.length; i++) {
        ws.cell(1, i+1)
        .string(cabecera[i])
        .style(style);
    }
    req.body.forEach((d,i)=>{
        ws.cell(i+2, 1)
        .number(i+1);
        ws.cell(i+2, 2)
        .string(`${d.tipo_iden} ${d.identificacion}`);
        ws.cell(i+2, 3)
        .string(d.nombre1);
        ws.cell(i+2, 4)
        .string(d.nombre2);
        ws.cell(i+2, 5)
        .string(d.apellido1);
        ws.cell(i+2, 6)
        .string(d.apellido2);
        ws.cell(i+2, 7)
        .string(d.correo);
        ws.cell(i+2, 8)
        .string(`${d.celular}`);
        ws.cell(i+2, 9)
        .string(d.ciudad);
        ws.cell(i+2, 10)
        .string(d.departamento);
        ws.cell(i+2, 11)
        .string(d.empresa);
        ws.cell(i+2, 12)
        .string(d.cargo);
        ws.cell(i+2, 13)
        .string(`${d.sector}`);
    });
    /*for (let j = 0; j < array.length; j++) {
        const element = array[j];
        
    }*/
    
    /*/ Set value of cell A3 to true as a boolean type styled with paramaters of style but with an adjustment to the font size.
    ws.cell(3, 1)
    .bool(true)
    .style(style)
    .style({font: {size: 14}});*/
    
    wb.write('./server/reportes/Excel.xlsx');
    enviaRutaPDF("Excel",res);
}

const enviaRutaPDF=(ruta,res)=>{
    /*var filePath = path.resolve(`./server/reportes/${ruta}.xlsx`);
    var arch=fs.statSync(filePath);
    res.writeHead(200, {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Length': arch.size
    });
    var readStream = fs.createReadStream(filePath);
    readStream.pipe(res);*/
    res.send({
        ok:true,
        ruta
    });
}

const enviaArchivo=(req,res)=>{
    let ruta=path.resolve(`./server/reportes/${req.params.nombre}.xlsx`);
    res.sendFile(ruta);
    setTimeout(() => {
        fs.unlink(ruta,(err)=>{});
    }, 5*1000);
}

module.exports={
    Crear,
    enviaArchivo
}