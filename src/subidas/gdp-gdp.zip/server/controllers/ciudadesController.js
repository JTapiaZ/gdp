const Ciud=require('../models/tbl_ciudades');

const guardarLote=(req,res)=>{
    Ciud.insertMany(req.body,(err,lista)=>{
        if(err){
            return res.json({
                ok:false,
                err
            });
        }
        res.json({
            ok:true,
            lista:req.body
        });
    });
}
const listar=(req,res)=>{
    Ciud.find({})
    .exec((err,lista)=>{
        if(err){
            return res.json({
                ok:false,
                err
            });
        }
        res.json({
            ok:true,
            lista
        });
    });
}

module.exports={
    guardarLote,
    listar
}