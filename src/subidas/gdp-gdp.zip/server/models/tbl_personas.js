const mongoose=require('mongoose');
const Schema=mongoose.Schema;

const tbl_persona=new Schema({
    identificacion:{
        type:String,
        required:true
    },
    tipo_iden:{
        type:String,
        required:true
    },
    nombre1:{
        type: String,
        required: false
    },
    nombre2:{
        type: String,
        required: false
    },
    apellido1:{
        type: String,
        required: true
    },
    apellido2:{
        type: String,
        required: false
    },
    sector:{
        type: String,
        required: false
    },
    empresa:{
        type: String,
        required: false
    },
    cargo:{
        type: String,
        required: false
    },
    ciudad:{
        type: Schema.Types.ObjectId,
        ref:"tbl_ciudades",
        required: false
    },
    departamento:{
        type: String,
        required: false
    },
    celular:{
        type: String,
        required: true
    },
    correo:{
        type:String,
        required:false
    },
    gen:{
        type:Boolean,
        required:true,
        default:false
    },
    estado:{
        type:Boolean,
        required:true,
        default:false
    }
});

module.exports=mongoose.model('tbl_persona',tbl_persona)