const mongoose=require('mongoose');
const Schema=mongoose.Schema;
const tbl_departamentos = new Schema({
    nombre_departamento:{
        type:String,
        required:true
    },
    id_departamento:{
        type:String,
        required:true
    }
});

module.exports=mongoose.model('tbl_departamentos',tbl_departamentos);
