const mongoose=require('mongoose');
const Schema=mongoose.Schema;
const tbl_usuarios = new Schema({
    correo:{
        type:String,
        required:false
    },
    usuario:{
        type:String,
        required:true
    },
    contrasena:{
        type:String,
        required:true
    }
});

module.exports=mongoose.model('tbl_usuarios',tbl_usuarios);