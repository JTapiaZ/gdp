const mongoose=require('mongoose');
const Schema=mongoose.Schema;
const tbl_ciudades = new Schema({
    nombre_ciudad:{
        type:String,
        required:true
    },
    id_departamento:{
        type:String,
        required:true
    }
});

module.exports=mongoose.model('tbl_ciudades',tbl_ciudades);
