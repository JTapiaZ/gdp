const {
    verificaToken
} = require('../middlewares/autenticacion');
const express = require('express');
const App = express();

//rutas personas
const personasController = require('../controllers/personasController');
App.get("/personas/inh/:id/:e", personasController.inhabilitar);
App.get("/personas/inh/:id", personasController.inhabilitar);
App.get("/personas/aceptados", personasController.aceptados);
App.get("/personas/:id", personasController.Buscar);
App.get("/personas/permitido/:id", personasController.permitido);
App.get("/personas", personasController.listar);
App.post("/personas/:id/:acepta", personasController.modificar);
App.post("/personas/lote", personasController.guardarLote);
App.post("/personas/:id", personasController.modificar);
App.post("/personas", personasController.guardar);

const reportesController = require('../controllers/reportesController');
App.post("/reportes/crear", reportesController.Crear);
App.get("/reportes/:nombre", reportesController.enviaArchivo);


const ciudadesController = require('../controllers/ciudadesController');
App.post("/ciudades/lote", ciudadesController.guardarLote);
App.get("/ciudades", ciudadesController.listar);

const departamentosController = require('../controllers/departamentosController');
App.post("/departamentos/lote", departamentosController.guardarLote);
App.get("/departamentos", departamentosController.listar);

const usuariosController = require('../controllers/usuariosController');

App.post("/iniciosesion", usuariosController.IniciarSesion);
App.post("/usuarios", usuariosController.GuardarUsuario);

module.exports = App;