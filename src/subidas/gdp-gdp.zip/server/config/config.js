// Puerto del servidor
process.env.PORT = process.env.PORT || 3008;

//Entorno, desarrollo, produccion
process.env.NODE_ENV = process.env.NODE_ENV || 'dev';

process.env.CADUCIDAD_TOKEN = '8h';

// SEED
process.env.SEED = process.env.SEED || 'eventoSena';

if (process.env.NODE_ENV === 'dev'){
    process.env.URLDB= 'mongodb://localhost:27017/Evento';
}else {
    process.env.URLDB= 'mongodb+srv://encuentrodelsuroeste:3ncu3ntr0@cluster0-hiitd.mongodb.net/test?retryWrites=true';
}